/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/mnt/hgfs/patrick/Dropbox/University-College-London/UCL-CS/Year-3/Research-Project/cpu-fpga-nwofle/hw/Hello-World/hello.v";
static const char *ng1 = "Hello World!";



static void Initial_7_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2040U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(7, ng0);

LAB4:    xsi_set_current_line(8, ng0);
    xsi_vlogfile_write(1, 0, 0, ng1, 1, t0);
    xsi_set_current_line(9, ng0);
    t2 = (t0 + 1848);
    xsi_process_wait(t2, 80000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(9, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}


extern void work_m_00000000000000000000_0953343723_init()
{
	static char *pe[] = {(void *)Initial_7_0};
	xsi_register_didat("work_m_00000000000000000000_0953343723", "isim/hello_isim_beh.exe.sim/work/m_00000000000000000000_0953343723.didat");
	xsi_register_executes(pe);
}
