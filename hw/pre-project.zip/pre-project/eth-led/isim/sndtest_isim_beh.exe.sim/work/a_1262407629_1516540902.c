/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/mnt/hgfs/patrick/Dropbox/University-College-London/UCL-CS/Year-3/Research-Project/cpu-fpga-nwofle/hw/eth-led/io.vhd";
extern char *IEEE_P_2592010699;
extern char *WORK_P_2188849903;

unsigned char ieee_p_2592010699_sub_2763492388968962707_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_2592010699_sub_3488546069778340532_503743352(char *, unsigned char , unsigned char );
unsigned char work_p_2188849903_sub_3510711976883097134_1032961590(char *, char *, char *, int );


static void work_a_1262407629_1516540902_p_0(char *t0)
{
    char t19[16];
    char t20[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned char t8;
    unsigned int t9;
    int t10;
    char *t11;
    int t12;
    int t13;
    unsigned char t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t21;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5};

LAB0:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t1 = (t0 + 9328);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 144U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(88, ng0);
    t1 = (t0 + 9392);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(90, ng0);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t7 = (0 + 0U);
    t1 = (t2 + t7);
    t8 = *((unsigned char *)t1);
    t3 = (char *)((nl0) + t8);
    goto **((char **)t3);

LAB2:    t1 = (t0 + 9184);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(93, ng0);
    t4 = (t0 + 5032U);
    t5 = *((char **)t4);
    t9 = (0 + 132U);
    t4 = (t5 + t9);
    t10 = *((int *)t4);
    t6 = (t0 + 6048U);
    t11 = *((char **)t6);
    t12 = *((int *)t11);
    t13 = (t12 - 1);
    t14 = (t10 == t13);
    if (t14 != 0)
        goto LAB6;

LAB8:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t7 = (0 + 132U);
    t1 = (t2 + t7);
    t10 = *((int *)t1);
    t12 = (t10 + 1);
    t3 = (t0 + 9328);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t11 = *((char **)t6);
    *((int *)t11) = t12;
    xsi_driver_first_trans_delta(t3, 129U, 1, 0LL);

LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(106, ng0);
    t1 = (t0 + 19566);
    t3 = (t0 + 3912U);
    t4 = *((char **)t3);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t20 + 0U);
    t11 = (t6 + 0U);
    *((int *)t11) = 0;
    t11 = (t6 + 4U);
    *((int *)t11) = 11;
    t11 = (t6 + 8U);
    *((int *)t11) = 1;
    t10 = (11 - 0);
    t7 = (t10 * 1);
    t7 = (t7 + 1);
    t11 = (t6 + 12U);
    *((unsigned int *)t11) = t7;
    t11 = (t0 + 18712U);
    t3 = xsi_base_array_concat(t3, t19, t5, (char)97, t1, t20, (char)97, t4, t11, (char)101);
    t7 = (12U + 4U);
    t8 = (16U != t7);
    if (t8 == 1)
        goto LAB12;

LAB13:    t15 = (t0 + 9328);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    memcpy(t21, t3, 16U);
    xsi_driver_first_trans_delta(t15, 49U, 16U, 0LL);
    xsi_set_current_line(107, ng0);
    t1 = (t0 + 19578);
    t3 = (t0 + 4392U);
    t4 = *((char **)t3);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t20 + 0U);
    t11 = (t6 + 0U);
    *((int *)t11) = 0;
    t11 = (t6 + 4U);
    *((int *)t11) = 11;
    t11 = (t6 + 8U);
    *((int *)t11) = 1;
    t10 = (11 - 0);
    t7 = (t10 * 1);
    t7 = (t7 + 1);
    t11 = (t6 + 12U);
    *((unsigned int *)t11) = t7;
    t11 = (t0 + 18760U);
    t3 = xsi_base_array_concat(t3, t19, t5, (char)97, t1, t20, (char)97, t4, t11, (char)101);
    t7 = (12U + 4U);
    t8 = (16U != t7);
    if (t8 == 1)
        goto LAB14;

LAB15:    t15 = (t0 + 9328);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    memcpy(t21, t3, 16U);
    xsi_driver_first_trans_delta(t15, 17U, 16U, 0LL);
    xsi_set_current_line(108, ng0);
    t1 = (t0 + 19590);
    t3 = (t0 + 4232U);
    t4 = *((char **)t3);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t20 + 0U);
    t11 = (t6 + 0U);
    *((int *)t11) = 0;
    t11 = (t6 + 4U);
    *((int *)t11) = 11;
    t11 = (t6 + 8U);
    *((int *)t11) = 1;
    t10 = (11 - 0);
    t7 = (t10 * 1);
    t7 = (t7 + 1);
    t11 = (t6 + 12U);
    *((unsigned int *)t11) = t7;
    t11 = (t0 + 18744U);
    t3 = xsi_base_array_concat(t3, t19, t5, (char)97, t1, t20, (char)97, t4, t11, (char)101);
    t7 = (12U + 4U);
    t8 = (16U != t7);
    if (t8 == 1)
        goto LAB16;

LAB17:    t15 = (t0 + 9328);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    memcpy(t21, t3, 16U);
    xsi_driver_first_trans_delta(t15, 1U, 16U, 0LL);
    xsi_set_current_line(109, ng0);
    t1 = (t0 + 9328);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB2;

LAB5:    xsi_set_current_line(112, ng0);
    t1 = (t0 + 9392);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(113, ng0);
    t1 = (t0 + 9328);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)0;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    xsi_set_current_line(114, ng0);
    t1 = (t0 + 9456);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(94, ng0);
    t6 = (t0 + 9328);
    t15 = (t6 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    *((int *)t18) = 0;
    xsi_driver_first_trans_delta(t6, 129U, 1, 0LL);
    xsi_set_current_line(95, ng0);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t7 = (0 + 136U);
    t1 = (t2 + t7);
    t10 = *((int *)t1);
    t3 = (t0 + 5928U);
    t4 = *((char **)t3);
    t12 = *((int *)t4);
    t13 = (t12 - 1);
    t8 = (t10 == t13);
    if (t8 != 0)
        goto LAB9;

LAB11:    xsi_set_current_line(99, ng0);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t7 = (0 + 136U);
    t1 = (t2 + t7);
    t10 = *((int *)t1);
    t12 = (t10 + 1);
    t3 = (t0 + 9328);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t11 = *((char **)t6);
    *((int *)t11) = t12;
    xsi_driver_first_trans_delta(t3, 130U, 1, 0LL);

LAB10:    goto LAB7;

LAB9:    xsi_set_current_line(96, ng0);
    t3 = (t0 + 9328);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t11 = (t6 + 56U);
    t15 = *((char **)t11);
    *((int *)t15) = 0;
    xsi_driver_first_trans_delta(t3, 130U, 1, 0LL);
    xsi_set_current_line(97, ng0);
    t1 = (t0 + 9328);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)1;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB10;

LAB12:    xsi_size_not_matching(16U, t7, 0);
    goto LAB13;

LAB14:    xsi_size_not_matching(16U, t7, 0);
    goto LAB15;

LAB16:    xsi_size_not_matching(16U, t7, 0);
    goto LAB17;

}

static void work_a_1262407629_1516540902_p_1(char *t0)
{
    char *t1;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(119, ng0);

LAB3:    t1 = (t0 + 19602);
    t3 = (t0 + 9520);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 8U);
    xsi_driver_first_trans_fast_port(t3);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1262407629_1516540902_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(120, ng0);

LAB3:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (0 + 1U);
    t1 = (t2 + t3);
    t4 = (t0 + 9584);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 128U);
    xsi_driver_first_trans_fast_port(t4);

LAB2:    t9 = (t0 + 9200);
    *((int *)t9) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1262407629_1516540902_p_3(char *t0)
{
    char t29[16];
    char t32[16];
    char t34[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned char t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    int t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t30;
    char *t31;
    char *t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5, &&LAB6};

LAB0:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t1 = (t0 + 9648);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 48U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(134, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t7 = (23 - 23);
    t8 = (t7 * -1);
    t9 = (1U * t8);
    t10 = (0 + 9U);
    t11 = (t10 + t9);
    t1 = (t2 + t11);
    t12 = *((unsigned char *)t1);
    t3 = (t0 + 9712);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t13 = *((char **)t6);
    *((unsigned char *)t13) = t12;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(135, ng0);
    t1 = (t0 + 9776);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(136, ng0);
    t1 = (t0 + 9840);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(137, ng0);
    t1 = (t0 + 9904);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(138, ng0);
    t1 = (t0 + 9968);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(139, ng0);
    t1 = (t0 + 10032);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(141, ng0);
    t1 = (t0 + 10096);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(143, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 0U);
    t1 = (t2 + t8);
    t12 = *((unsigned char *)t1);
    t3 = (char *)((nl0) + t12);
    goto **((char **)t3);

LAB2:    t1 = (t0 + 9216);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(145, ng0);
    t4 = (t0 + 1672U);
    t5 = *((char **)t4);
    t14 = *((unsigned char *)t5);
    t15 = (t14 == (unsigned char)3);
    if (t15 != 0)
        goto LAB7;

LAB9:
LAB8:    goto LAB2;

LAB4:    xsi_set_current_line(155, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 1U);
    t1 = (t2 + t8);
    t3 = (t0 + 11400);
    t4 = xsi_record_get_element_type(t3, 1);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t13 = ((WORK_P_2188849903) + 2008U);
    t16 = *((char **)t13);
    t7 = *((int *)t16);
    t12 = work_p_2188849903_sub_3510711976883097134_1032961590(WORK_P_2188849903, t1, t6, t7);
    if (t12 != 0)
        goto LAB10;

LAB12:
LAB11:    xsi_set_current_line(162, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 1U);
    t1 = (t2 + t8);
    t3 = (t0 + 11400);
    t4 = xsi_record_get_element_type(t3, 1);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t13 = ((WORK_P_2188849903) + 1888U);
    t16 = *((char **)t13);
    t7 = *((int *)t16);
    t12 = work_p_2188849903_sub_3510711976883097134_1032961590(WORK_P_2188849903, t1, t6, t7);
    if (t12 != 0)
        goto LAB13;

LAB15:
LAB14:    xsi_set_current_line(169, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (7 - 3);
    t9 = (t8 * 1U);
    t10 = (0 + 1U);
    t11 = (t10 + t9);
    t1 = (t2 + t11);
    t3 = (t0 + 19610);
    t12 = 1;
    if (4U == 4U)
        goto LAB19;

LAB20:    t12 = 0;

LAB21:    if ((!(t12)) != 0)
        goto LAB16;

LAB18:    xsi_set_current_line(172, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)0;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);

LAB17:    goto LAB2;

LAB5:    xsi_set_current_line(183, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 1U);
    t1 = (t2 + t8);
    t3 = (t0 + 11400);
    t4 = xsi_record_get_element_type(t3, 1);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t13 = ((WORK_P_2188849903) + 1168U);
    t16 = *((char **)t13);
    t7 = *((int *)t16);
    t12 = work_p_2188849903_sub_3510711976883097134_1032961590(WORK_P_2188849903, t1, t6, t7);
    if (t12 != 0)
        goto LAB25;

LAB27:    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 1U);
    t1 = (t2 + t8);
    t3 = (t0 + 11400);
    t4 = xsi_record_get_element_type(t3, 1);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t13 = ((WORK_P_2188849903) + 1288U);
    t16 = *((char **)t13);
    t7 = *((int *)t16);
    t12 = work_p_2188849903_sub_3510711976883097134_1032961590(WORK_P_2188849903, t1, t6, t7);
    if (t12 != 0)
        goto LAB30;

LAB31:    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 1U);
    t1 = (t2 + t8);
    t3 = (t0 + 11400);
    t4 = xsi_record_get_element_type(t3, 1);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t13 = ((WORK_P_2188849903) + 1408U);
    t16 = *((char **)t13);
    t7 = *((int *)t16);
    t12 = work_p_2188849903_sub_3510711976883097134_1032961590(WORK_P_2188849903, t1, t6, t7);
    if (t12 != 0)
        goto LAB34;

LAB35:    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 1U);
    t1 = (t2 + t8);
    t3 = (t0 + 11400);
    t4 = xsi_record_get_element_type(t3, 1);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t13 = ((WORK_P_2188849903) + 1528U);
    t16 = *((char **)t13);
    t7 = *((int *)t16);
    t12 = work_p_2188849903_sub_3510711976883097134_1032961590(WORK_P_2188849903, t1, t6, t7);
    if (t12 != 0)
        goto LAB38;

LAB39:    xsi_set_current_line(200, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)0;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);

LAB26:    goto LAB2;

LAB6:    xsi_set_current_line(207, ng0);
    t1 = (t0 + 9904);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(208, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t12 = *((unsigned char *)t2);
    t1 = (t0 + 9776);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = t12;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(209, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (23 - 22);
    t9 = (t8 * 1U);
    t10 = (0 + 9U);
    t11 = (t10 + t9);
    t1 = (t2 + t11);
    t4 = ((IEEE_P_2592010699) + 4000);
    t5 = (t32 + 0U);
    t6 = (t5 + 0U);
    *((int *)t6) = 22;
    t6 = (t5 + 4U);
    *((int *)t6) = 4;
    t6 = (t5 + 8U);
    *((int *)t6) = -1;
    t7 = (4 - 22);
    t21 = (t7 * -1);
    t21 = (t21 + 1);
    t6 = (t5 + 12U);
    *((unsigned int *)t6) = t21;
    t3 = xsi_base_array_concat(t3, t29, t4, (char)97, t1, t32, (char)99, (unsigned char)2, (char)101);
    t21 = (19U + 1U);
    t12 = (20U != t21);
    if (t12 == 1)
        goto LAB42;

LAB43:    t6 = (t0 + 9648);
    t13 = (t6 + 56U);
    t16 = *((char **)t13);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t3, 20U);
    xsi_driver_first_trans_delta(t6, 9U, 20U, 0LL);
    xsi_set_current_line(210, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 44U);
    t1 = (t2 + t8);
    t7 = *((int *)t1);
    t12 = (t7 == 23);
    if (t12 != 0)
        goto LAB44;

LAB46:    xsi_set_current_line(214, ng0);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t8 = (0 + 44U);
    t1 = (t2 + t8);
    t7 = *((int *)t1);
    t19 = (t7 + 1);
    t3 = (t0 + 9648);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t13 = *((char **)t6);
    *((int *)t13) = t19;
    xsi_driver_first_trans_delta(t3, 41U, 1, 0LL);
    xsi_set_current_line(215, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);

LAB45:    goto LAB2;

LAB7:    xsi_set_current_line(146, ng0);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    t4 = (t0 + 9648);
    t13 = (t4 + 56U);
    t16 = *((char **)t13);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t6, 8U);
    xsi_driver_first_trans_delta(t4, 1U, 8U, 0LL);
    xsi_set_current_line(147, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)1;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB8;

LAB10:    xsi_set_current_line(156, ng0);
    t13 = (t0 + 1512U);
    t17 = *((char **)t13);
    t9 = (15 - 7);
    t10 = (t9 * 1U);
    t13 = ((WORK_P_2188849903) + 2008U);
    t18 = *((char **)t13);
    t19 = *((int *)t18);
    t20 = (t19 - 7);
    t11 = (t20 * -1);
    t21 = (16U * t11);
    t22 = (0 + t21);
    t23 = (t22 + t10);
    t13 = (t17 + t23);
    t24 = (t0 + 9648);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t13, 8U);
    xsi_driver_first_trans_delta(t24, 33U, 8U, 0LL);
    xsi_set_current_line(157, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 1U, 1, 0LL);
    goto LAB11;

LAB13:    xsi_set_current_line(163, ng0);
    t13 = (t0 + 1512U);
    t17 = *((char **)t13);
    t9 = (15 - 3);
    t10 = (t9 * 1U);
    t13 = ((WORK_P_2188849903) + 1888U);
    t18 = *((char **)t13);
    t19 = *((int *)t18);
    t20 = (t19 - 7);
    t11 = (t20 * -1);
    t21 = (16U * t11);
    t22 = (0 + t21);
    t23 = (t22 + t10);
    t13 = (t17 + t23);
    t24 = (t0 + 9648);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t13, 4U);
    xsi_driver_first_trans_delta(t24, 29U, 4U, 0LL);
    xsi_set_current_line(164, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 2U, 1, 0LL);
    goto LAB14;

LAB16:    xsi_set_current_line(170, ng0);
    t13 = (t0 + 9648);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t24 = *((char **)t18);
    *((unsigned char *)t24) = (unsigned char)2;
    xsi_driver_first_trans_delta(t13, 0U, 1, 0LL);
    goto LAB17;

LAB19:    t21 = 0;

LAB22:    if (t21 < 4U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t5 = (t1 + t21);
    t6 = (t3 + t21);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB20;

LAB24:    t21 = (t21 + 1);
    goto LAB22;

LAB25:    xsi_set_current_line(184, ng0);
    t13 = (t0 + 6168U);
    t17 = *((char **)t13);
    t13 = (t0 + 6288U);
    t18 = *((char **)t13);
    t24 = ((IEEE_P_2592010699) + 4000);
    t25 = (t0 + 18904U);
    t26 = (t0 + 18920U);
    t13 = xsi_base_array_concat(t13, t29, t24, (char)97, t17, t25, (char)97, t18, t26, (char)101);
    t27 = (t0 + 1512U);
    t28 = *((char **)t27);
    t9 = (15 - 11);
    t10 = (t9 * 1U);
    t27 = ((WORK_P_2188849903) + 1168U);
    t30 = *((char **)t27);
    t19 = *((int *)t30);
    t20 = (t19 - 7);
    t11 = (t20 * -1);
    t21 = (16U * t11);
    t22 = (0 + t21);
    t23 = (t22 + t10);
    t27 = (t28 + t23);
    t33 = ((IEEE_P_2592010699) + 4000);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 11;
    t36 = (t35 + 4U);
    *((int *)t36) = 0;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 11);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t31 = xsi_base_array_concat(t31, t32, t33, (char)97, t13, t29, (char)97, t27, t34, (char)101);
    t38 = (4U + 4U);
    t39 = (t38 + 12U);
    t14 = (20U != t39);
    if (t14 == 1)
        goto LAB28;

LAB29:    t36 = (t0 + 9648);
    t40 = (t36 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t31, 20U);
    xsi_driver_first_trans_delta(t36, 9U, 20U, 0LL);
    xsi_set_current_line(185, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 8U, 1, 0LL);
    xsi_set_current_line(186, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB26;

LAB28:    xsi_size_not_matching(20U, t39, 0);
    goto LAB29;

LAB30:    xsi_set_current_line(188, ng0);
    t13 = (t0 + 6168U);
    t17 = *((char **)t13);
    t13 = (t0 + 6408U);
    t18 = *((char **)t13);
    t24 = ((IEEE_P_2592010699) + 4000);
    t25 = (t0 + 18904U);
    t26 = (t0 + 18936U);
    t13 = xsi_base_array_concat(t13, t29, t24, (char)97, t17, t25, (char)97, t18, t26, (char)101);
    t27 = (t0 + 1512U);
    t28 = *((char **)t27);
    t9 = (15 - 11);
    t10 = (t9 * 1U);
    t27 = ((WORK_P_2188849903) + 1288U);
    t30 = *((char **)t27);
    t19 = *((int *)t30);
    t20 = (t19 - 7);
    t11 = (t20 * -1);
    t21 = (16U * t11);
    t22 = (0 + t21);
    t23 = (t22 + t10);
    t27 = (t28 + t23);
    t33 = ((IEEE_P_2592010699) + 4000);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 11;
    t36 = (t35 + 4U);
    *((int *)t36) = 0;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 11);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t31 = xsi_base_array_concat(t31, t32, t33, (char)97, t13, t29, (char)97, t27, t34, (char)101);
    t38 = (4U + 4U);
    t39 = (t38 + 12U);
    t14 = (20U != t39);
    if (t14 == 1)
        goto LAB32;

LAB33:    t36 = (t0 + 9648);
    t40 = (t36 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t31, 20U);
    xsi_driver_first_trans_delta(t36, 9U, 20U, 0LL);
    xsi_set_current_line(189, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 7U, 1, 0LL);
    xsi_set_current_line(190, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB26;

LAB32:    xsi_size_not_matching(20U, t39, 0);
    goto LAB33;

LAB34:    xsi_set_current_line(192, ng0);
    t13 = (t0 + 6168U);
    t17 = *((char **)t13);
    t13 = (t0 + 6528U);
    t18 = *((char **)t13);
    t24 = ((IEEE_P_2592010699) + 4000);
    t25 = (t0 + 18904U);
    t26 = (t0 + 18952U);
    t13 = xsi_base_array_concat(t13, t29, t24, (char)97, t17, t25, (char)97, t18, t26, (char)101);
    t27 = (t0 + 1512U);
    t28 = *((char **)t27);
    t9 = (15 - 11);
    t10 = (t9 * 1U);
    t27 = ((WORK_P_2188849903) + 1408U);
    t30 = *((char **)t27);
    t19 = *((int *)t30);
    t20 = (t19 - 7);
    t11 = (t20 * -1);
    t21 = (16U * t11);
    t22 = (0 + t21);
    t23 = (t22 + t10);
    t27 = (t28 + t23);
    t33 = ((IEEE_P_2592010699) + 4000);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 11;
    t36 = (t35 + 4U);
    *((int *)t36) = 0;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 11);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t31 = xsi_base_array_concat(t31, t32, t33, (char)97, t13, t29, (char)97, t27, t34, (char)101);
    t38 = (4U + 4U);
    t39 = (t38 + 12U);
    t14 = (20U != t39);
    if (t14 == 1)
        goto LAB36;

LAB37:    t36 = (t0 + 9648);
    t40 = (t36 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t31, 20U);
    xsi_driver_first_trans_delta(t36, 9U, 20U, 0LL);
    xsi_set_current_line(193, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 6U, 1, 0LL);
    xsi_set_current_line(194, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB26;

LAB36:    xsi_size_not_matching(20U, t39, 0);
    goto LAB37;

LAB38:    xsi_set_current_line(196, ng0);
    t13 = (t0 + 6168U);
    t17 = *((char **)t13);
    t13 = (t0 + 6648U);
    t18 = *((char **)t13);
    t24 = ((IEEE_P_2592010699) + 4000);
    t25 = (t0 + 18904U);
    t26 = (t0 + 18968U);
    t13 = xsi_base_array_concat(t13, t29, t24, (char)97, t17, t25, (char)97, t18, t26, (char)101);
    t27 = (t0 + 1512U);
    t28 = *((char **)t27);
    t9 = (15 - 11);
    t10 = (t9 * 1U);
    t27 = ((WORK_P_2188849903) + 1528U);
    t30 = *((char **)t27);
    t19 = *((int *)t30);
    t20 = (t19 - 7);
    t11 = (t20 * -1);
    t21 = (16U * t11);
    t22 = (0 + t21);
    t23 = (t22 + t10);
    t27 = (t28 + t23);
    t33 = ((IEEE_P_2592010699) + 4000);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 11;
    t36 = (t35 + 4U);
    *((int *)t36) = 0;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 11);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t31 = xsi_base_array_concat(t31, t32, t33, (char)97, t13, t29, (char)97, t27, t34, (char)101);
    t38 = (4U + 4U);
    t39 = (t38 + 12U);
    t14 = (20U != t39);
    if (t14 == 1)
        goto LAB40;

LAB41:    t36 = (t0 + 9648);
    t40 = (t36 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t31, 20U);
    xsi_driver_first_trans_delta(t36, 9U, 20U, 0LL);
    xsi_set_current_line(197, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 5U, 1, 0LL);
    xsi_set_current_line(198, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB26;

LAB40:    xsi_size_not_matching(20U, t39, 0);
    goto LAB41;

LAB42:    xsi_size_not_matching(20U, t21, 0);
    goto LAB43;

LAB44:    xsi_set_current_line(211, ng0);
    t3 = (t0 + 9648);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t13 = *((char **)t6);
    *((int *)t13) = 0;
    xsi_driver_first_trans_delta(t3, 41U, 1, 0LL);
    xsi_set_current_line(212, ng0);
    t1 = (t0 + 9648);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB45;

}

static void work_a_1262407629_1516540902_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(272, ng0);

LAB3:    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t3 = (0 + 29U);
    t1 = (t2 + t3);
    t4 = (t0 + 10160);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);

LAB2:    t9 = (t0 + 9232);
    *((int *)t9) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1262407629_1516540902_p_5(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;

LAB0:    xsi_set_current_line(277, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_2763492388968962707_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 9248);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(278, ng0);
    t3 = (t0 + 4872U);
    t4 = *((char **)t3);
    t3 = (t0 + 10224);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t4, 48U);
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(279, ng0);
    t1 = (t0 + 5192U);
    t3 = *((char **)t1);
    t1 = (t0 + 10288);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 144U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(280, ng0);
    t1 = (t0 + 5352U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 2632U);
    t4 = *((char **)t1);
    t9 = *((unsigned char *)t4);
    t10 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t2, t9);
    t1 = (t0 + 10352);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t10;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(281, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 10416);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t2;
    xsi_driver_first_trans_delta(t1, 7U, 1, 0LL);
    xsi_set_current_line(282, ng0);
    t1 = (t0 + 5352U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 10416);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t2;
    xsi_driver_first_trans_delta(t1, 6U, 1, 0LL);
    xsi_set_current_line(283, ng0);
    t1 = (t0 + 5512U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 10416);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t2;
    xsi_driver_first_trans_delta(t1, 5U, 1, 0LL);
    goto LAB3;

}


extern void work_a_1262407629_1516540902_init()
{
	static char *pe[] = {(void *)work_a_1262407629_1516540902_p_0,(void *)work_a_1262407629_1516540902_p_1,(void *)work_a_1262407629_1516540902_p_2,(void *)work_a_1262407629_1516540902_p_3,(void *)work_a_1262407629_1516540902_p_4,(void *)work_a_1262407629_1516540902_p_5};
	xsi_register_didat("work_a_1262407629_1516540902", "isim/sndtest_isim_beh.exe.sim/work/a_1262407629_1516540902.didat");
	xsi_register_executes(pe);
}
