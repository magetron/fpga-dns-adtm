/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif



unsigned char work_p_2188849903_sub_3510711976883097134_1032961590(char *t1, char *t2, char *t3, int t4)
{
    char t6[24];
    unsigned char t0;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    int t12;
    char *t13;
    int t14;
    int t15;
    unsigned int t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;

LAB0:    t7 = (t6 + 4U);
    t8 = (t2 != 0);
    if (t8 == 1)
        goto LAB3;

LAB2:    t9 = (t6 + 12U);
    *((char **)t9) = t3;
    t10 = (t6 + 20U);
    *((int *)t10) = t4;
    t11 = (t3 + 0U);
    t12 = *((int *)t11);
    t13 = (t3 + 8U);
    t14 = *((int *)t13);
    t15 = (t4 - t12);
    t16 = (t15 * t14);
    t17 = (t3 + 4U);
    t18 = *((int *)t17);
    xsi_vhdl_check_range_of_index(t12, t18, t14, t4);
    t19 = (1U * t16);
    t20 = (0 + t19);
    t21 = (t2 + t20);
    t22 = *((unsigned char *)t21);
    t23 = (t22 == (unsigned char)3);
    t0 = t23;

LAB1:    return t0;
LAB3:    *((char **)t7) = t2;
    goto LAB2;

LAB4:;
}


extern void work_p_2188849903_init()
{
	static char *se[] = {(void *)work_p_2188849903_sub_3510711976883097134_1032961590};
	xsi_register_didat("work_p_2188849903", "isim/sndtest_isim_beh.exe.sim/work/p_2188849903.didat");
	xsi_register_subprogram_executes(se);
}
